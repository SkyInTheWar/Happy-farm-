let player;
let scene = "campo"; // ou "cidade"
let animals = [];
let foods = ["🥐", "🥖", "🥞", "🍥"];
let lojaAberta = false;
let moedas = 0;
let vendedorMsg = "";
let comprados = [];
let unicornio = null;
let unicornioSpawned = false;
let unicornioTimer = 0;
let unicornioFalaTimer = 0;
let unicornioFala = "";
let estrelaSound;
let musicaCampo;
let musicaCidade;




function drawUnicornio() {
  if (unicornio) {
    // Desenha o unicórnio
    textSize(32);
    text("🦄", unicornio.x, unicornio.y);

    // Segue o jogador
    let dx = player.x - unicornio.x;
    let dy = player.y - unicornio.y;
    let distTotal = dist(player.x, player.y, unicornio.x, unicornio.y);
    if (distTotal > 1) {
      unicornio.x += dx * 0.02;
      unicornio.y += dy * 0.02;
    }

    // Fala 🎉 ou 💕 a cada 8 segundos
    if (millis() - unicornioFalaTimer > 8000) {
      unicornioFala = random(["🎉", "💕"]);
      unicornioFalaTimer = millis();
    }

    if (unicornioFala) {
      textSize(16);
      text(unicornioFala, unicornio.x, unicornio.y - 30);
    }

    // Desaparece após 30 segundos
    if (millis() - unicornioTimer > 30000) {
      unicornio = null;
    }
  }
}

let imgCampo, imgCidade;

function preload() {
  imgCampo = loadImage("campo.jpg");
  imgCidade = loadImage("cidade.jpg");
  estrelaSound = loadSound("estrela.mp3");
  musicaCampo = loadSound("campo.mp3");

  musicaCidade = loadSound("cidade.mp3");
  
  
  
}

function setup() {
  createCanvas(800, 600);
  musicaCampo.loop();
  player = createPlayer();
  gerarAnimais();
}

function createPlayer() {
  return {
    x: width / 2,
    y: height / 2,
    size: 32,
  };
}

function gerarAnimais() {
  animals = [];

  let emojis = ["🐄", "🐇", "🐓", "🐑"];

  for (let i = 0; i < 5; i++) {
    animals.push({
      x: random(0, 900), // X entre 0 e 100

      y: random(0, 600), // Y entre 0 e 200

      emoji: random(emojis),

      vivo: true,

      mensagem: "",
    });
  }
  // Spawn do unicórnio limitado à mesma área (opcional)

  if (!unicornioSpawned && random(1) < 0.02) {
    unicornio = {
      x: random(0, 900),

      y: random(0, 600),

      tempo: 0,
    };

    unicornioSpawned = true;

    unicornioTimer = millis();

    unicornioFalaTimer = millis();

    moedas += 80;
    if (estrelaSound && estrelaSound.isLoaded()) {
      estrelaSound.play();
    }
  }
}

function draw() {
  if (scene === "campo") {
    image(imgCampo, 0, 0, width, height);
    drawCampo();
  } else {
    image(imgCidade, 0, 0, width, height);
    drawCidade();
    drawUnicornio();
  }

  // Jogador
  textSize(32);
  textAlign(CENTER, CENTER);
  text("🎃", player.x, player.y);

  handleMovement();

  if (scene === "campo") {
    drawCampo();
  } else {
    drawCidade();
  }

  drawMoedas();
}

function handleMovement() {
  if (keyIsDown(LEFT_ARROW)) player.x -= 3;
  if (keyIsDown(RIGHT_ARROW)) player.x += 3;
  if (keyIsDown(UP_ARROW)) player.y -= 3;
  if (keyIsDown(DOWN_ARROW)) player.y += 3;
}

function drawCampo() {
  for (let a of animals) {
    if (a.vivo) {
      text(a.emoji, a.x, a.y);
    } else {
      fill(0);
      textSize(16);
      text(":(", a.x, a.y + 20);
      fill(255);
    }
  }
}

function drawCidade() {
  // Loja e vendedor
  textSize(32);
  if (lojaAberta) {
    fill(255);
    rect(100, 100, 600, 400, 20);
    fill(0);
    textAlign(LEFT, TOP);
    text("⛄", 150, 130);
    textSize(16);
    text("compre as comidas exclusivas da cidade", 190, 140);

    for (let i = 0; i < foods.length; i++) {
      textSize(24);
      text(foods[i], 200 + i * 60, 250);
    }

    textSize(16);
    text("Fale com ⛄ e diga: 'okk' ou 'ta.'", 190, 300);
    if (vendedorMsg) {
      text("⛄ diz: " + vendedorMsg, 190, 330);
    }

    if (comprados.length > 0) {
      text("Você comprou: " + comprados.join(" "), 190, 370);
    }
  }
}

function drawMoedas() {
  fill(0);
  textSize(16);
  textAlign(LEFT, TOP);
  text("Moedas: " + moedas, 10, 10);
}

function keyPressed() {
  if (key === "C") {
    scene = scene === "campo" ? "cidade" : "campo";
    if (scene === "campo") {
      gerarAnimais();
      
if (musicaCampo.isPlaying()) musicaCampo.stop();

      musicaCidade.loop();

    } else {

      cenario = "campo";

      if (musicaCidade.isPlaying()) musicaCidade.stop();

      musicaCampo.loop();
    }
  }

  if (key === "K" && scene === "campo") {
    for (let a of animals) {
      if (a.vivo && dist(player.x, player.y, a.x, a.y) < 50) {
        a.vivo = false;
        moedas += 1;
        a.mensagem = ":(";
      }
    }

    // Impede ataque ao unicórnio
    if (unicornio && dist(player.x, player.y, unicornio.x, unicornio.y) < 50) {
      // Nada acontece, ele é imortal
    }
  }

  if (key === "L" && scene === "cidade") {
    lojaAberta = !lojaAberta;
  }
}

function keyTyped() {
  if (scene === "cidade" && lojaAberta && (key === "o" || key === "t")) {
    vendedorMsg = key === "o" ? "okk" : "ta.";
    if (moedas >= 2) {
      let comida = random(foods);
      comprados.push(comida);
      moedas -= 2;
    } else {
      vendedorMsg = "moedas insuficientes";
    }
  }
}
